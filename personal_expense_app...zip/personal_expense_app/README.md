# personal_expense_app

Personal Expense App with Flutter.

## Screenshot
<img src="../img/all.png" alt="All" width="500" height="auto"/>

<img src="../img/delete.png" alt="Delete" width="500" height="auto"/>

<img src="../img/add.png" alt="Add" width="500" height="auto"/>

<img src="../img/added.png" alt="Added" width="500" height="auto"/>

